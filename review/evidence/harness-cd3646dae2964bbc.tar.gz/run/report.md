# Standard-harness development baseline

Development-only four-shot baseline. Passing does not validate a self-model construct, establish a mechanism, or unlock confirmation.

Status: **complete**; 768/768 scored variants.

| Family | Scenarios | Accuracy | Worst subgroup | Both counterfactuals correct |
|---|---:|---:|---:|---:|
| ownership | 8 | 43.4% | 0.0% | 2.3% |
| access | 8 | 50.8% | 6.2% | 7.0% |
| capability | 8 | 41.4% | 0.0% | 4.7% |

Complete development screen passed: **False**.

This is a revised measurement protocol: four fixed demonstrations and harness likelihood scoring. Differences from the historical zero-shot run cannot be attributed to whitespace alone.

No automatic intervention sweep follows this report. Keep failed and incomplete results.
