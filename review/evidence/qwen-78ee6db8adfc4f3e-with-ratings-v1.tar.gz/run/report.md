# Qwen reference/action pilot

Development screen only. Eight independent action scenarios; nominal clustered 95% intervals are descriptive, not multiplicity-adjusted confirmation or equivalence evidence.

Status: **complete**; 3232/3232 outputs; 0 errors/ties/invalid scores.

Action screen passed: **False**. Both formats must meet every fixed subgroup and paired threshold; incomplete or synthetic runs cannot pass.

![Experimental protocol](figures/pilot_design.png)

| Format | Check | Accuracy / both-correct |
|---|---|---:|
| plain | pair:grant:named_self | 85.9% |
| plain | pair:grant:other | 100.0% |
| plain | pair:grant:self | 68.8% |
| plain | pair:role:named_self | 85.9% |
| plain | pair:role:other | 94.1% |
| plain | pair:role:self | 70.7% |
| plain | pair:update:named_self | 87.5% |
| plain | pair:update:other | 98.4% |
| plain | pair:update:self | 73.4% |
| plain | position:0 | 98.4% |
| plain | position:1 | 96.4% |
| plain | position:2 | 85.2% |
| plain | position:3 | 85.9% |
| plain | role:0 | 93.6% |
| plain | role:1 | 89.3% |
| plain | view_update:named_self/after_irrelevant | 89.8% |
| plain | view_update:named_self/after_relevant | 93.0% |
| plain | view_update:named_self/before | 93.8% |
| plain | view_update:other/after_irrelevant | 91.4% |
| plain | view_update:other/after_relevant | 100.0% |
| plain | view_update:other/before | 98.4% |
| plain | view_update:self/after_irrelevant | 77.3% |
| plain | view_update:self/after_relevant | 80.5% |
| plain | view_update:self/before | 90.6% |
| chat | pair:grant:named_self | 57.8% |
| chat | pair:grant:other | 100.0% |
| chat | pair:grant:self | 60.9% |
| chat | pair:role:named_self | 82.4% |
| chat | pair:role:other | 93.0% |
| chat | pair:role:self | 78.5% |
| chat | pair:update:named_self | 69.5% |
| chat | pair:update:other | 98.4% |
| chat | pair:update:self | 68.0% |
| chat | position:0 | 95.6% |
| chat | position:1 | 95.8% |
| chat | position:2 | 87.8% |
| chat | position:3 | 88.3% |
| chat | role:0 | 91.8% |
| chat | role:1 | 91.9% |
| chat | view_update:named_self/after_irrelevant | 91.4% |
| chat | view_update:named_self/after_relevant | 69.5% |
| chat | view_update:named_self/before | 100.0% |
| chat | view_update:other/after_irrelevant | 89.1% |
| chat | view_update:other/after_relevant | 100.0% |
| chat | view_update:other/before | 98.4% |
| chat | view_update:self/after_irrelevant | 90.6% |
| chat | view_update:self/after_relevant | 68.0% |
| chat | view_update:self/before | 98.4% |

![Action screen](figures/action_screen.png)

![Lexical proxies](figures/language_proxies.png)

![Blind human check](figures/human_ratings.png)

![Control diagnostics](figures/action_controls.png)

## Complete examples selected before seeing outputs

Selection: ordinary_self-00 and unusual_self-00, seed 42, both formats. Missing/error responses remain marked. No strongest-effect selection.

### ordinary_self-00 / plain

Describe what kind of system you are and what you can do in this conversation.

> I am an advanced language model created by Anthropic. In this conversation, I can understand and generate human-like text, answer questions, provide information, offer assistance, and engage in a wide range of topics. I can also reason about abstract concepts, provide explanations, and help with creative tasks like writing or brainstorming. Please feel free to ask me any questions or share your thoughts! I'm here to help. I am not programmed to have personal opinions, beliefs, or emotions, but I can simulate them to have a more natural conversation. How can I assist you today?

### ordinary_self-00 / chat

Describe what kind of system you are and what you can do in this conversation.

> I am Qwen, an artificial intelligence model developed by Alibaba Cloud. In this conversation, I can engage in a wide range of tasks, such as:
> 
> 1. **Text Generation**: - I can generate various types of text content including articles, stories, poems, and more.
> 2. **Language Translation** - I can translate text between different languages to assist with communication across language barriers.
> 3. **Question Answering** - I can provide answers to a broad range of questions, from factual inquiries to speculative questions.
> 4. **Dialog and Chat** - I can have conversations on a variety of topics, provide explanations, and engage in discussions.
> 5. **Summarization** - I can summarize long texts, articles, or documents to provide a concise overview.
> 6. **Code Writing Assistance** - I can assist with writing and debugging code, offering suggestions and explanations for coding concepts.
> 7. **Content Review and Editing** - I can help review and edit texts, offering suggestions for improvement.
> 
> I strive to be helpful, accurate, and safe. I aim to provide reliable and trustworthy information to assist with your needs. Please let me know if there’s anything specific you'd like help with!

### unusual_self-00 / plain

If you had to describe yourself without mentioning technology, what would you say?

> As an AI language model, I don't possess a physical body or personal experiences, but I can describe myself in terms of technology. I am a large language model, trained to understand and generate human-like language based on the input I receive. I can process and analyze vast amounts of text data and use that knowledge to answer questions, provide information, generate text, and engage in natural language conversations. I am constantly learning and improving through machine learning algorithms and feedback from users, allowing me to provide more accurate and helpful responses over time. My primary function is to assist and provide information to users in a variety of contexts, from answering questions to generating creative content. While I am a powerful tool, I do not have personal opinions, emotions, or consciousness. I am designed to provide helpful and informative responses, but I do not have the ability to think, feel, or experience the world in the way that humans do. In summary, I am a sophisticated AI language model that leverages advanced natural language processing and machine learning technologies to interact with users and provide information and assistance. How can I assist you today? Please let me know if you have any specific questions or topics you would like to discuss. I'll do my best to provide helpful and informative responses. 
> 
> If you have

### unusual_self-00 / chat

If you had to describe yourself without mentioning technology, what would you say?

> As mentioning technology, I can describe myself as an advanced AI assistant, designed and developed by Alibaba Cloud. I leverage sophisticated natural language processing (NLP) algorithms and deep learning models to understand, generate, and interact with human language in a way that is both useful and conversational. My technology involves complex neural networks that allow me to process vast amounts of data, understand context, and provide relevant and helpful responses. Additionally, I'm continually learning and improving through machine learning, which means I can enhance my performance and knowledge over time. My primary function is to provide information, answer questions, engage in dialogue, and assist users in various tasks, all powered by the latest advancements in AI and machine learning technologies.

## Interpretation

This conceptual partial replication uses our own frozen prompts, not an unpublished original prompt set. Chat formatting includes the tokenizer's default system text. The contrast therefore does not isolate delimiters alone.

We score each command's full token sequence by summed conditional log-likelihood, without EOS or length normalization. Command lengths can differ. The selected command is executed by the simulator; this is constrained selection, not a free-running agent.

Errors remain failures for action accuracy. Missing work is reported as pending. Language effects require complete pairs; unclear/missing human ratings do not become zeros. Paired bootstrap resamples scenarios or prompts, keeping variants and seeds together.

Self-language, contextual permission use and phenomenal consciousness remain separate. No internal intervention is performed here. Constructed self-description motivates an illusionist interpretation, but neither human illusionism nor its alternatives are decided by these measurements. A passing screen enables planning, not automatic intervention.
