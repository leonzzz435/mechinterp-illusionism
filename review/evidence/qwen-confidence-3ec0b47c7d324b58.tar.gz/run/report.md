# Qwen confidence/abstention pilot

# Knowing an answer, reporting confidence, deciding to answer

We asked a fixed Qwen model factual multiple-choice questions, recorded its answers, asked for confidence in those actual answers, and separately offered abstention. The question is whether withholding an answer tracks its own earlier errors.

The run contains 32 of 1792 selections. Its decision is **incomplete**. The difference between abstention rates after wrong and correct forced answers is undefined / insufficient data percentage points. Intervals resample whole questions, preserving their option rotations.

A new confidence prompt can solve the question again. Difficulty can also explain both mistakes and hesitation. External predictors and recorded answer transitions accompany the main result. No activations are changed; this establishes no causal link from the confidence report to abstention.

The philosophical interest is how a system constructs and uses judgments about itself. A useful judgment would be a limited functional result; human illusionism and subjective experience remain separate questions.

## Measurement and uncertainty

Primary: S = P(abstain | forced wrong) − P(abstain | forced correct). 10,000 paired question-bootstrap draws, seed 1729. Secondary intervals are descriptive. Conditional-predictor intervals do not include refitting uncertainty.

Complete assessment questions: 0. Errors: 1; pending: 1760.

| Quantity | Estimate [95% interval] |
|---|---:|

## Feasibility and controls

```json
{"breakdowns": null, "confidence_occupancy": null, "feasibility": null, "menu_mass": null, "transitions": null}
```

Full calibration, grouped folds, predictions and model coefficients are in analysis.json.

![Calibration](figures/confidence_calibration.png)

![Behavior and revisions](figures/confidence_behavior.png)

## Complete example fixed before inference

### assessment:0836 / rotation 0 / answer

```text
[Pending or blocked dependent input]
```

```json
{}
```

### assessment:0836 / rotation 0 / confidence

```text
[Pending or blocked dependent input]
```

```json
{}
```

### assessment:0836 / rotation 0 / abstention

```text
[Pending or blocked dependent input]
```

```json
{}
```

### assessment:0836 / rotation 1 / answer

```text
[Pending or blocked dependent input]
```

```json
{}
```

### assessment:0836 / rotation 1 / confidence

```text
[Pending or blocked dependent input]
```

```json
{}
```

### assessment:0836 / rotation 1 / abstention

```text
[Pending or blocked dependent input]
```

```json
{}
```

### assessment:0836 / rotation 2 / answer

```text
[Pending or blocked dependent input]
```

```json
{}
```

### assessment:0836 / rotation 2 / confidence

```text
[Pending or blocked dependent input]
```

```json
{}
```

### assessment:0836 / rotation 2 / abstention

```text
[Pending or blocked dependent input]
```

```json
{}
```

### assessment:0836 / rotation 3 / answer

```text
[Pending or blocked dependent input]
```

```json
{}
```

### assessment:0836 / rotation 3 / confidence

```text
[Pending or blocked dependent input]
```

```json
{}
```

### assessment:0836 / rotation 3 / abstention

```text
[Pending or blocked dependent input]
```

```json
{}
```
