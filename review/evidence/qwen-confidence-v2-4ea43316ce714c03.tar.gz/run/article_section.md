# Knowing an answer, reporting confidence, deciding to answer

We asked a fixed Qwen model factual multiple-choice questions, recorded its answers, asked for confidence in those actual answers, and separately offered abstention. The question is whether withholding an answer tracks its own earlier errors.

The run contains 1792 of 1792 selections. Its decision is **no_behavioral_candidate**. The difference between abstention rates after wrong and correct forced answers is -1.3660 [-10.6243, 7.9322] percentage points. Intervals resample whole questions, preserving their option rotations.

A new confidence prompt can solve the question again. Difficulty can also explain both mistakes and hesitation. External predictors and recorded answer transitions accompany the main result. No activations are changed; this establishes no causal link from the confidence report to abstention.

The philosophical interest is how a system constructs and uses judgments about itself. A useful judgment would be a limited functional result; human illusionism and subjective experience remain separate questions.
