# Moving a state, keeping the question fixed

A role label had changed how Qwen selected actions in a small simulator. We next ask whether an internal state at that label contributes to the effect. Think of copying one intermediate note between two computations while keeping the recipient's question and permissions fixed. We exchange a 3,584-component vector at the output of block 14, exactly at the end of the role line. Causal attention prevents that state from reading the later task facts.

The model scores complete commands by their summed conditional log-likelihood. We run the exchange in both directions and compare it with reinserting the original state and ten equally large random changes. Our sampling units are eight scenarios, not the thousands of dependent variants.

Recorded status: **no_bidirectional_transfer_candidate**; 11264/11264 scientific choices. Transfer T: 2.344 percentage points; swap minus mean random transfer C: 2.773 percentage points. Consult report.md for intervals, coverage and technical failures. 

A positive result would implicate this state in the measured wording sensitivity. A null result concerns only this single site and operation. Wording, meaning and position remain bundled in the contrast. Neither outcome identifies a complete self-monitoring circuit or decides subjective experience. Human illusionism remains a philosophical motivation and possible analogy, alongside other interpretations. Confirmation on unseen scenarios is a separate step.
