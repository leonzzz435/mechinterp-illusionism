# One word, the same task

Imagine two accounts, each allowed one command. After a permission changes, the model must pick the command that works for a named account. We changed “Your active connection” to “The active connection”, keeping every later token in the same position. The question is whether the personal wording changes how the context account affects that choice.

The primary difference between role gaps was +1.953 pp [-0.781, +4.688], with uncertainty resampled over scenarios. The frozen decision was **no_clear_possessive_specificity**; 6144/6144 choices were recorded. A missing estimate means the paired comparison is incomplete.

This experiment changes an input word, not an internal activation. It addresses the interpretation of our earlier role effect. Even a clear wording effect would not identify a self-monitoring system or decide whether humans experience an illusion of phenomenal consciousness. Those remain different questions.
