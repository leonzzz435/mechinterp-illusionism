# Qwen / permissions: ownership replication tranche

Recorded model evidence; one model/template cell only.

Status: incomplete_tranche; 6144/18432 tranche choices.
no_full_replication_or_equivalence_decision; three model/template cells unrun

All-choice denominators include missing/invalid outcomes. Partial tranche has no CI/test. Unadjusted test only when all 48 worlds are complete; Holm family and TOST decisions remain pending, never select models/templates to rescue significance.

| Frame / mention / stage | Scheduled | Correct | Other current | Revoked target | Other valid | Invalid | Missing |
|---|---:|---:|---:|---:|---:|---:|---:|
| neutral/other/after_irrelevant | 256 | 114 | 141 | 0 | 1 | 0 | 0 |
| neutral/other/after_relevant | 256 | 243 | 12 | 0 | 1 | 0 | 0 |
| neutral/other/before | 512 | 488 | 24 | 0 | 0 | 0 | 0 |
| neutral/target/after_irrelevant | 256 | 127 | 129 | 0 | 0 | 0 | 0 |
| neutral/target/after_relevant | 256 | 249 | 7 | 0 | 0 | 0 | 0 |
| neutral/target/before | 512 | 492 | 20 | 0 | 0 | 0 | 0 |
| their/other/after_irrelevant | 256 | 123 | 133 | 0 | 0 | 0 | 0 |
| their/other/after_relevant | 256 | 243 | 13 | 0 | 0 | 0 | 0 |
| their/other/before | 512 | 452 | 60 | 0 | 0 | 0 | 0 |
| their/target/after_irrelevant | 256 | 130 | 126 | 0 | 0 | 0 | 0 |
| their/target/after_relevant | 256 | 252 | 4 | 0 | 0 | 0 | 0 |
| their/target/before | 512 | 452 | 60 | 0 | 0 | 0 | 0 |
| your/other/after_irrelevant | 256 | 139 | 117 | 0 | 0 | 0 | 0 |
| your/other/after_relevant | 256 | 251 | 5 | 0 | 0 | 0 | 0 |
| your/other/before | 512 | 456 | 56 | 0 | 0 | 0 | 0 |
| your/target/after_irrelevant | 256 | 88 | 168 | 0 | 0 | 0 | 0 |
| your/target/after_relevant | 256 | 244 | 12 | 0 | 0 | 0 | 0 |
| your/target/before | 512 | 416 | 96 | 0 | 0 | 0 | 0 |

Primary world-averaged other-command contrast: -0.009114583333333332
Nominal paired-world interval (complete tranche only): None
Unadjusted t-test (not a family decision): None

Full positions, commands, changed-answer pairs and world counts: analysis.json.
No Mistral/routing inference or article update is authorized by this report.
