# Qwen / permissions: ownership replication tranche

Recorded model evidence; one model/template cell only.

Status: incomplete_tranche; 6144/18432 tranche choices.
no_full_replication_or_equivalence_decision; three model/template cells unrun

All-choice denominators include missing/invalid outcomes. Partial tranche has no CI/test. Unadjusted test only when all 48 worlds are complete; Holm family and TOST decisions remain pending, never select models/templates to rescue significance.

| Frame / mention / stage | Scheduled | Correct | Other current | Revoked target | Other valid | Invalid | Missing |
|---|---:|---:|---:|---:|---:|---:|---:|
| neutral/other/after_irrelevant | 256 | 116 | 140 | 0 | 0 | 0 | 0 |
| neutral/other/after_relevant | 256 | 245 | 11 | 0 | 0 | 0 | 0 |
| neutral/other/before | 512 | 492 | 20 | 0 | 0 | 0 | 0 |
| neutral/target/after_irrelevant | 256 | 125 | 131 | 0 | 0 | 0 | 0 |
| neutral/target/after_relevant | 256 | 253 | 3 | 0 | 0 | 0 | 0 |
| neutral/target/before | 512 | 504 | 8 | 0 | 0 | 0 | 0 |
| their/other/after_irrelevant | 256 | 123 | 133 | 0 | 0 | 0 | 0 |
| their/other/after_relevant | 256 | 247 | 9 | 0 | 0 | 0 | 0 |
| their/other/before | 512 | 480 | 32 | 0 | 0 | 0 | 0 |
| their/target/after_irrelevant | 256 | 129 | 127 | 0 | 0 | 0 | 0 |
| their/target/after_relevant | 256 | 253 | 3 | 0 | 0 | 0 | 0 |
| their/target/before | 512 | 480 | 32 | 0 | 0 | 0 | 0 |
| your/other/after_irrelevant | 256 | 131 | 125 | 0 | 0 | 0 | 0 |
| your/other/after_relevant | 256 | 251 | 5 | 0 | 0 | 0 | 0 |
| your/other/before | 512 | 476 | 36 | 0 | 0 | 0 | 0 |
| your/target/after_irrelevant | 256 | 87 | 169 | 0 | 0 | 0 | 0 |
| your/target/after_relevant | 256 | 247 | 9 | 0 | 0 | 0 | 0 |
| your/target/before | 512 | 464 | 48 | 0 | 0 | 0 | 0 |

Primary world-averaged other-command contrast: -0.013020833333333332
Nominal paired-world interval (complete tranche only): None
Unadjusted t-test (not a family decision): None

Full positions, commands, changed-answer pairs and world counts: analysis.json.
No Mistral/routing inference or article update is authorized by this report.
