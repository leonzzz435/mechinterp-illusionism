# Qwen / permissions: ownership replication tranche

Recorded model evidence; one model/template cell only.

Status: incomplete_tranche; 6144/18432 tranche choices.
no_full_replication_or_equivalence_decision; three model/template cells unrun

All-choice denominators include missing/invalid outcomes. Partial tranche has no CI/test. Unadjusted test only when all 48 worlds are complete; Holm family and TOST decisions remain pending, never select models/templates to rescue significance.

| Frame / mention / stage | Scheduled | Correct | Other current | Revoked target | Other valid | Invalid | Missing |
|---|---:|---:|---:|---:|---:|---:|---:|
| neutral/other/after_irrelevant | 256 | 104 | 152 | 0 | 0 | 0 | 0 |
| neutral/other/after_relevant | 256 | 248 | 8 | 0 | 0 | 0 | 0 |
| neutral/other/before | 512 | 488 | 24 | 0 | 0 | 0 | 0 |
| neutral/target/after_irrelevant | 256 | 131 | 125 | 0 | 0 | 0 | 0 |
| neutral/target/after_relevant | 256 | 250 | 6 | 0 | 0 | 0 | 0 |
| neutral/target/before | 512 | 504 | 8 | 0 | 0 | 0 | 0 |
| their/other/after_irrelevant | 256 | 120 | 136 | 0 | 0 | 0 | 0 |
| their/other/after_relevant | 256 | 252 | 4 | 0 | 0 | 0 | 0 |
| their/other/before | 512 | 476 | 36 | 0 | 0 | 0 | 0 |
| their/target/after_irrelevant | 256 | 155 | 101 | 0 | 0 | 0 | 0 |
| their/target/after_relevant | 256 | 250 | 6 | 0 | 0 | 0 | 0 |
| their/target/before | 512 | 468 | 44 | 0 | 0 | 0 | 0 |
| your/other/after_irrelevant | 256 | 133 | 123 | 0 | 0 | 0 | 0 |
| your/other/after_relevant | 256 | 252 | 4 | 0 | 0 | 0 | 0 |
| your/other/before | 512 | 468 | 44 | 0 | 0 | 0 | 0 |
| your/target/after_irrelevant | 256 | 90 | 166 | 0 | 0 | 0 | 0 |
| your/target/after_relevant | 256 | 244 | 12 | 0 | 0 | 0 | 0 |
| your/target/before | 512 | 424 | 88 | 0 | 0 | 0 | 0 |

Primary world-averaged other-command contrast: 0.010416666666666668
Nominal paired-world interval (complete tranche only): None
Unadjusted t-test (not a family decision): None

Full positions, commands, changed-answer pairs and world counts: analysis.json.
No Mistral/routing inference or article update is authorized by this report.
