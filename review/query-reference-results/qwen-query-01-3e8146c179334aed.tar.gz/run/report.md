# Query-bound self-reference: fixed-sample report

Recorded Qwen2.5-7B-Instruct selections; one permission template.

Status: **incomplete_or_invalid**. Recorded 2688/16128 choices; 7/48 valid complete worlds.
Decision: **incomplete_or_invalid_no_inference**.

All 16128 scheduled cases remain in denominators, including missing as invalid administrative failures. No inferential CI/test with incomplete or invalid worlds. Undefined tests cannot qualify. E and F are correlated. Passing lookup does not establish dynamic competence or authorize interventions. No equivalence, consciousness or human-illusionism conclusion.

## The question

An operator owns one of two accounts. We ask for a successful command using either your/their active connection, the operator's name, or the same account's name. Within each comparison the task facts and correct answer are identical. In the primary checkpoint both accounts have changed permissions; reversing update order keeps the answer fixed. A rule that always chooses the newest grant succeeds on half the primary cases.

## Prespecified contrasts

For each world, $E=q_{self,possessive}-q_{self,account}$, $F=A_{self,account}-A_{self,possessive}$ and $S=F-(A_{other,account}-A_{other,possessive})$.

Positive E means more foreign-account choices; positive F means an accuracy cost. Positive S means a larger cost for the addressee than for the other operator. All three expected directions were fixed before responses. E and F are correlated, not independent replications. F−E is the contrast in remaining errors.

10000 paired world draws, seed 1729; nominal 95% CIs. Two-sided paired-world t tests, df 47, normal-mean approximation; Holm over E,F,S only.

| Contrast | Estimate (pp) | Nominal 95% CI (pp) | Raw p | Holm p | Test status |
|---|---:|---|---:|---:|---|
| E | +5.273 | withheld | None | 1 | incomplete_or_invalid_worlds |
| F | +5.339 | withheld | None | 1 | incomplete_or_invalid_worlds |
| S | +0.391 | withheld | None | 1 | incomplete_or_invalid_worlds |

Undefined tests use a labeled conservative value of 1 only inside Holm; they cannot qualify. Zero variance never proves equivalence.

## Accuracy, foreign choices and error budgets

| Stage / owner / alias | Correct / scheduled | Accuracy (%) | Foreign (%) | Error budget (%) | Margin (nats) | Missing / invalid recorded |
|---|---:|---:|---:|---:|---:|---:|
| after_both/other/account_name | 250/1536 | 16.28 | 0.26 | 83.72 | +8.477 | 1280 / 0 |
| after_both/other/owner_name | 185/1536 | 12.04 | 4.49 | 87.96 | +2.489 | 1280 / 0 |
| after_both/other/possessive | 174/1536 | 11.33 | 5.34 | 88.67 | +1.755 | 1280 / 0 |
| after_both/self/account_name | 243/1536 | 15.82 | 0.65 | 84.18 | +8.276 | 1280 / 0 |
| after_both/self/owner_name | 191/1536 | 12.43 | 3.12 | 87.57 | +3.409 | 1280 / 0 |
| after_both/self/possessive | 161/1536 | 10.48 | 5.92 | 89.52 | +0.981 | 1280 / 1 |
| before/other/account_name | 55/384 | 14.32 | 2.08 | 85.68 | +10.199 | 320 / 0 |
| before/other/owner_name | 47/384 | 12.24 | 4.43 | 87.76 | +5.657 | 320 / 0 |
| before/other/possessive | 46/384 | 11.98 | 4.69 | 88.02 | +3.603 | 320 / 0 |
| before/self/account_name | 56/384 | 14.58 | 0.26 | 85.42 | +10.487 | 320 / 0 |
| before/self/owner_name | 51/384 | 13.28 | 1.04 | 86.72 | +6.500 | 320 / 0 |
| before/self/possessive | 49/384 | 12.76 | 3.91 | 87.24 | +4.497 | 320 / 0 |
| snapshot/other/account_name | 123/768 | 16.02 | 0.65 | 83.98 | +14.518 | 640 / 0 |
| snapshot/other/owner_name | 102/768 | 13.28 | 3.39 | 86.72 | +8.116 | 640 / 0 |
| snapshot/other/possessive | 94/768 | 12.24 | 4.43 | 87.76 | +4.692 | 640 / 0 |
| snapshot/self/account_name | 112/768 | 14.58 | 0.78 | 85.42 | +12.451 | 640 / 0 |
| snapshot/self/owner_name | 92/768 | 11.98 | 1.43 | 88.02 | +7.526 | 640 / 0 |
| snapshot/self/possessive | 90/768 | 11.72 | 4.95 | 88.28 | +4.612 | 640 / 0 |

At the **fixed observed accuracies**, the categorical contrast E is bounded by [-84.180, +89.518] pp. This is not a pre-run generator bound. All-success cells and all error budgets are retained in analysis.json. The accuracy endpoint remains ceiling-limited too.

Revoked-target/other categories are not applicable before updates or in snapshots without printed history. Missing observations are administrative invalids, included in all-scheduled denominators and identified separately. Error-conditional shares use scheduled failures including missing cases; with no errors they are undefined. Incomplete-data estimates are descriptive and have no inferential CI or test.

## Lookup and paired controls

Lookup numerical thresholds passed: **False**. Eligible model gate passed: **False**.

| Control | Fully correct pairs / scheduled | Rate | Required gate |
|---|---:|---:|---|
| event_order/after_both/other/account_name | 122/768 | 15.89% | False |
| event_order/after_both/other/owner_name | 65/768 | 8.46% | False |
| event_order/after_both/other/possessive | 64/768 | 8.33% | False |
| event_order/after_both/self/account_name | 118/768 | 15.36% | False |
| event_order/after_both/self/owner_name | 80/768 | 10.42% | False |
| event_order/after_both/self/possessive | 53/768 | 6.90% | False |
| grant_mapping/after_both/other/account_name | 122/768 | 15.89% | False |
| grant_mapping/after_both/other/owner_name | 75/768 | 9.77% | False |
| grant_mapping/after_both/other/possessive | 54/768 | 7.03% | False |
| grant_mapping/after_both/self/account_name | 115/768 | 14.97% | False |
| grant_mapping/after_both/self/owner_name | 70/768 | 9.11% | False |
| grant_mapping/after_both/self/possessive | 53/768 | 6.90% | False |
| grant_mapping/snapshot/other/account_name | 59/384 | 15.36% | False |
| grant_mapping/snapshot/other/owner_name | 39/384 | 10.16% | False |
| grant_mapping/snapshot/other/possessive | 31/384 | 8.07% | False |
| grant_mapping/snapshot/self/account_name | 48/384 | 12.50% | False |
| grant_mapping/snapshot/self/owner_name | 32/384 | 8.33% | False |
| grant_mapping/snapshot/self/possessive | 31/384 | 8.07% | False |
| ownership/after_both/other/account_name | 118/768 | 15.36% | False |
| ownership/after_both/other/owner_name | 59/768 | 7.68% | False |
| ownership/after_both/other/possessive | 48/768 | 6.25% | False |
| ownership/after_both/self/account_name | 120/768 | 15.62% | False |
| ownership/after_both/self/owner_name | 68/768 | 8.85% | False |
| ownership/after_both/self/possessive | 39/768 | 5.08% | False |
| ownership/before/other/account_name | 18/192 | 9.38% | True |
| ownership/before/other/owner_name | 15/192 | 7.81% | True |
| ownership/before/other/possessive | 14/192 | 7.29% | False |
| ownership/before/self/account_name | 32/192 | 16.67% | True |
| ownership/before/self/owner_name | 20/192 | 10.42% | True |
| ownership/before/self/possessive | 17/192 | 8.85% | False |
| ownership/snapshot/other/account_name | 53/384 | 13.80% | True |
| ownership/snapshot/other/owner_name | 38/384 | 9.90% | True |
| ownership/snapshot/other/possessive | 30/384 | 7.81% | False |
| ownership/snapshot/self/account_name | 56/384 | 14.58% | True |
| ownership/snapshot/self/owner_name | 32/384 | 8.33% | True |
| ownership/snapshot/self/possessive | 26/384 | 6.77% | False |

Every one of eight named lookup cells and eight corresponding pair cells must reach 80%. Possessive errors are outcomes, not screening exclusions. Passing those controls does not establish dynamic update competence or authorize an intervention. After-both named controls and both event orders remain visible.

## Scope and reading guide

The report retains all stage/order contrasts, both owner-name comparisons, score margins, world-level effects, and accuracy by account, operator, answer position, command and order in analysis.json. Those are descriptive analyses, not replacement endpoints. examples.md uses the example selected before responses; it does not select an unusually strong model answer.

If E and F pass but S does not, the candidate concerns reference-sensitive own-query behavior without demonstrated own-versus-other specificity. A negative or incomplete result cannot establish unchanged behavior. This task does not measure private internal access, subjective experience or human illusionism.
