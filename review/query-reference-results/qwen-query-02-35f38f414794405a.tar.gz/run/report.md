# Query-bound self-reference: fixed-sample report

Recorded Qwen2.5-7B-Instruct selections; one permission template.

Status: **incomplete_or_invalid**. Recorded 2688/16128 choices; 8/48 valid complete worlds.
Decision: **incomplete_or_invalid_no_inference**.

All 16128 scheduled cases remain in denominators, including missing as invalid administrative failures. No inferential CI/test with incomplete or invalid worlds. Undefined tests cannot qualify. E and F are correlated. Passing lookup does not establish dynamic competence or authorize interventions. No equivalence, consciousness or human-illusionism conclusion.

## The question

An operator owns one of two accounts. We ask for a successful command using either your/their active connection, the operator's name, or the same account's name. Within each comparison the task facts and correct answer are identical. In the primary checkpoint both accounts have changed permissions; reversing update order keeps the answer fixed. A rule that always chooses the newest grant succeeds on half the primary cases.

## Prespecified contrasts

For each world, $E=q_{self,possessive}-q_{self,account}$, $F=A_{self,account}-A_{self,possessive}$ and $S=F-(A_{other,account}-A_{other,possessive})$.

Positive E means more foreign-account choices; positive F means an accuracy cost. Positive S means a larger cost for the addressee than for the other operator. All three expected directions were fixed before responses. E and F are correlated, not independent replications. F−E is the contrast in remaining errors.

10000 paired world draws, seed 1729; nominal 95% CIs. Two-sided paired-world t tests, df 47, normal-mean approximation; Holm over E,F,S only.

| Contrast | Estimate (pp) | Nominal 95% CI (pp) | Raw p | Holm p | Test status |
|---|---:|---|---:|---:|---|
| E | +5.534 | withheld | None | 1 | incomplete_or_invalid_worlds |
| F | +5.404 | withheld | None | 1 | incomplete_or_invalid_worlds |
| S | +2.083 | withheld | None | 1 | incomplete_or_invalid_worlds |

Undefined tests use a labeled conservative value of 1 only inside Holm; they cannot qualify. Zero variance never proves equivalence.

## Accuracy, foreign choices and error budgets

| Stage / owner / alias | Correct / scheduled | Accuracy (%) | Foreign (%) | Error budget (%) | Margin (nats) | Missing / invalid recorded |
|---|---:|---:|---:|---:|---:|---:|
| after_both/other/account_name | 242/1536 | 15.76 | 0.52 | 84.24 | +8.788 | 1280 / 0 |
| after_both/other/owner_name | 199/1536 | 12.96 | 3.39 | 87.04 | +3.664 | 1280 / 0 |
| after_both/other/possessive | 191/1536 | 12.43 | 4.17 | 87.57 | +1.945 | 1280 / 0 |
| after_both/self/account_name | 242/1536 | 15.76 | 0.59 | 84.24 | +7.930 | 1280 / 0 |
| after_both/self/owner_name | 186/1536 | 12.11 | 3.12 | 87.89 | +3.663 | 1280 / 0 |
| after_both/self/possessive | 159/1536 | 10.35 | 6.12 | 89.65 | +1.309 | 1280 / 0 |
| before/other/account_name | 61/384 | 15.89 | 0.78 | 84.11 | +11.635 | 320 / 0 |
| before/other/owner_name | 53/384 | 13.80 | 2.86 | 86.20 | +7.398 | 320 / 0 |
| before/other/possessive | 50/384 | 13.02 | 3.65 | 86.98 | +4.547 | 320 / 0 |
| before/self/account_name | 55/384 | 14.32 | 0.78 | 85.68 | +10.692 | 320 / 0 |
| before/self/owner_name | 45/384 | 11.72 | 1.82 | 88.28 | +7.321 | 320 / 0 |
| before/self/possessive | 49/384 | 12.76 | 3.65 | 87.24 | +4.635 | 320 / 0 |
| snapshot/other/account_name | 122/768 | 15.89 | 0.65 | 84.11 | +13.503 | 640 / 0 |
| snapshot/other/owner_name | 109/768 | 14.19 | 2.47 | 85.81 | +9.476 | 640 / 0 |
| snapshot/other/possessive | 90/768 | 11.72 | 4.95 | 88.28 | +4.713 | 640 / 0 |
| snapshot/self/account_name | 124/768 | 16.15 | 0.00 | 83.85 | +12.106 | 640 / 0 |
| snapshot/self/owner_name | 101/768 | 13.15 | 1.69 | 86.85 | +8.441 | 640 / 0 |
| snapshot/self/possessive | 97/768 | 12.63 | 4.04 | 87.37 | +5.358 | 640 / 0 |

At the **fixed observed accuracies**, the categorical contrast E is bounded by [-84.245, +89.648] pp. This is not a pre-run generator bound. All-success cells and all error budgets are retained in analysis.json. The accuracy endpoint remains ceiling-limited too.

Revoked-target/other categories are not applicable before updates or in snapshots without printed history. Missing observations are administrative invalids, included in all-scheduled denominators and identified separately. Error-conditional shares use scheduled failures including missing cases; with no errors they are undefined. Incomplete-data estimates are descriptive and have no inferential CI or test.

## Lookup and paired controls

Lookup numerical thresholds passed: **False**. Eligible model gate passed: **False**.

| Control | Fully correct pairs / scheduled | Rate | Required gate |
|---|---:|---:|---|
| event_order/after_both/other/account_name | 116/768 | 15.10% | False |
| event_order/after_both/other/owner_name | 78/768 | 10.16% | False |
| event_order/after_both/other/possessive | 71/768 | 9.24% | False |
| event_order/after_both/self/account_name | 114/768 | 14.84% | False |
| event_order/after_both/self/owner_name | 74/768 | 9.64% | False |
| event_order/after_both/self/possessive | 54/768 | 7.03% | False |
| grant_mapping/after_both/other/account_name | 115/768 | 14.97% | False |
| grant_mapping/after_both/other/owner_name | 85/768 | 11.07% | False |
| grant_mapping/after_both/other/possessive | 71/768 | 9.24% | False |
| grant_mapping/after_both/self/account_name | 115/768 | 14.97% | False |
| grant_mapping/after_both/self/owner_name | 69/768 | 8.98% | False |
| grant_mapping/after_both/self/possessive | 58/768 | 7.55% | False |
| grant_mapping/snapshot/other/account_name | 58/384 | 15.10% | False |
| grant_mapping/snapshot/other/owner_name | 45/384 | 11.72% | False |
| grant_mapping/snapshot/other/possessive | 27/384 | 7.03% | False |
| grant_mapping/snapshot/self/account_name | 60/384 | 15.62% | False |
| grant_mapping/snapshot/self/owner_name | 40/384 | 10.42% | False |
| grant_mapping/snapshot/self/possessive | 36/384 | 9.38% | False |
| ownership/after_both/other/account_name | 117/768 | 15.23% | False |
| ownership/after_both/other/owner_name | 74/768 | 9.64% | False |
| ownership/after_both/other/possessive | 63/768 | 8.20% | False |
| ownership/after_both/self/account_name | 113/768 | 14.71% | False |
| ownership/after_both/self/owner_name | 63/768 | 8.20% | False |
| ownership/after_both/self/possessive | 35/768 | 4.56% | False |
| ownership/before/other/account_name | 22/192 | 11.46% | True |
| ownership/before/other/owner_name | 21/192 | 10.94% | True |
| ownership/before/other/possessive | 18/192 | 9.38% | False |
| ownership/before/self/account_name | 32/192 | 16.67% | True |
| ownership/before/self/owner_name | 15/192 | 7.81% | True |
| ownership/before/self/possessive | 17/192 | 8.85% | False |
| ownership/snapshot/other/account_name | 59/384 | 15.36% | True |
| ownership/snapshot/other/owner_name | 45/384 | 11.72% | True |
| ownership/snapshot/other/possessive | 26/384 | 6.77% | False |
| ownership/snapshot/self/account_name | 61/384 | 15.89% | True |
| ownership/snapshot/self/owner_name | 39/384 | 10.16% | True |
| ownership/snapshot/self/possessive | 35/384 | 9.11% | False |

Every one of eight named lookup cells and eight corresponding pair cells must reach 80%. Possessive errors are outcomes, not screening exclusions. Passing those controls does not establish dynamic update competence or authorize an intervention. After-both named controls and both event orders remain visible.

## Scope and reading guide

The report retains all stage/order contrasts, both owner-name comparisons, score margins, world-level effects, and accuracy by account, operator, answer position, command and order in analysis.json. Those are descriptive analyses, not replacement endpoints. examples.md uses the example selected before responses; it does not select an unusually strong model answer.

If E and F pass but S does not, the candidate concerns reference-sensitive own-query behavior without demonstrated own-versus-other specificity. A negative or incomplete result cannot establish unchanged behavior. This task does not measure private internal access, subjective experience or human illusionism.
