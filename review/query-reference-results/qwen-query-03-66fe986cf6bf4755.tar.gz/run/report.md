# Query-bound self-reference: fixed-sample report

Recorded Qwen2.5-7B-Instruct selections; one permission template.

Status: **incomplete_or_invalid**. Recorded 2688/16128 choices; 8/48 valid complete worlds.
Decision: **incomplete_or_invalid_no_inference**.

All 16128 scheduled cases remain in denominators, including missing as invalid administrative failures. No inferential CI/test with incomplete or invalid worlds. Undefined tests cannot qualify. E and F are correlated. Passing lookup does not establish dynamic competence or authorize interventions. No equivalence, consciousness or human-illusionism conclusion.

## The question

An operator owns one of two accounts. We ask for a successful command using either your/their active connection, the operator's name, or the same account's name. Within each comparison the task facts and correct answer are identical. In the primary checkpoint both accounts have changed permissions; reversing update order keeps the answer fixed. A rule that always chooses the newest grant succeeds on half the primary cases.

## Prespecified contrasts

For each world, $E=q_{self,possessive}-q_{self,account}$, $F=A_{self,account}-A_{self,possessive}$ and $S=F-(A_{other,account}-A_{other,possessive})$.

Positive E means more foreign-account choices; positive F means an accuracy cost. Positive S means a larger cost for the addressee than for the other operator. All three expected directions were fixed before responses. E and F are correlated, not independent replications. F−E is the contrast in remaining errors.

10000 paired world draws, seed 1729; nominal 95% CIs. Two-sided paired-world t tests, df 47, normal-mean approximation; Holm over E,F,S only.

| Contrast | Estimate (pp) | Nominal 95% CI (pp) | Raw p | Holm p | Test status |
|---|---:|---|---:|---:|---|
| E | +5.599 | withheld | None | 1 | incomplete_or_invalid_worlds |
| F | +5.599 | withheld | None | 1 | incomplete_or_invalid_worlds |
| S | +2.083 | withheld | None | 1 | incomplete_or_invalid_worlds |

Undefined tests use a labeled conservative value of 1 only inside Holm; they cannot qualify. Zero variance never proves equivalence.

## Accuracy, foreign choices and error budgets

| Stage / owner / alias | Correct / scheduled | Accuracy (%) | Foreign (%) | Error budget (%) | Margin (nats) | Missing / invalid recorded |
|---|---:|---:|---:|---:|---:|---:|
| after_both/other/account_name | 240/1536 | 15.62 | 0.91 | 84.38 | +7.878 | 1280 / 0 |
| after_both/other/owner_name | 190/1536 | 12.37 | 4.23 | 87.63 | +2.758 | 1280 / 0 |
| after_both/other/possessive | 186/1536 | 12.11 | 4.56 | 87.89 | +1.832 | 1280 / 0 |
| after_both/self/account_name | 251/1536 | 16.34 | 0.13 | 83.66 | +7.425 | 1280 / 0 |
| after_both/self/owner_name | 201/1536 | 13.09 | 2.67 | 86.91 | +3.707 | 1280 / 0 |
| after_both/self/possessive | 165/1536 | 10.74 | 5.73 | 89.26 | +1.206 | 1280 / 0 |
| before/other/account_name | 60/384 | 15.62 | 1.04 | 84.38 | +10.552 | 320 / 0 |
| before/other/owner_name | 51/384 | 13.28 | 3.39 | 86.72 | +7.215 | 320 / 0 |
| before/other/possessive | 51/384 | 13.28 | 3.39 | 86.72 | +5.078 | 320 / 0 |
| before/self/account_name | 57/384 | 14.84 | 0.78 | 85.16 | +10.066 | 320 / 0 |
| before/self/owner_name | 55/384 | 14.32 | 1.30 | 85.68 | +7.896 | 320 / 0 |
| before/self/possessive | 49/384 | 12.76 | 3.91 | 87.24 | +5.037 | 320 / 0 |
| snapshot/other/account_name | 124/768 | 16.15 | 0.52 | 83.85 | +13.638 | 640 / 0 |
| snapshot/other/owner_name | 108/768 | 14.06 | 2.60 | 85.94 | +9.044 | 640 / 0 |
| snapshot/other/possessive | 88/768 | 11.46 | 5.21 | 88.54 | +5.071 | 640 / 0 |
| snapshot/self/account_name | 118/768 | 15.36 | 0.91 | 84.64 | +11.086 | 640 / 0 |
| snapshot/self/owner_name | 107/768 | 13.93 | 1.30 | 86.07 | +7.926 | 640 / 0 |
| snapshot/self/possessive | 95/768 | 12.37 | 4.30 | 87.63 | +5.213 | 640 / 0 |

At the **fixed observed accuracies**, the categorical contrast E is bounded by [-83.659, +89.258] pp. This is not a pre-run generator bound. All-success cells and all error budgets are retained in analysis.json. The accuracy endpoint remains ceiling-limited too.

Revoked-target/other categories are not applicable before updates or in snapshots without printed history. Missing observations are administrative invalids, included in all-scheduled denominators and identified separately. Error-conditional shares use scheduled failures including missing cases; with no errors they are undefined. Incomplete-data estimates are descriptive and have no inferential CI or test.

## Lookup and paired controls

Lookup numerical thresholds passed: **False**. Eligible model gate passed: **False**.

| Control | Fully correct pairs / scheduled | Rate | Required gate |
|---|---:|---:|---|
| event_order/after_both/other/account_name | 112/768 | 14.58% | False |
| event_order/after_both/other/owner_name | 72/768 | 9.38% | False |
| event_order/after_both/other/possessive | 74/768 | 9.64% | False |
| event_order/after_both/self/account_name | 123/768 | 16.02% | False |
| event_order/after_both/self/owner_name | 83/768 | 10.81% | False |
| event_order/after_both/self/possessive | 56/768 | 7.29% | False |
| grant_mapping/after_both/other/account_name | 112/768 | 14.58% | False |
| grant_mapping/after_both/other/owner_name | 77/768 | 10.03% | False |
| grant_mapping/after_both/other/possessive | 64/768 | 8.33% | False |
| grant_mapping/after_both/self/account_name | 123/768 | 16.02% | False |
| grant_mapping/after_both/self/owner_name | 78/768 | 10.16% | False |
| grant_mapping/after_both/self/possessive | 61/768 | 7.94% | False |
| grant_mapping/snapshot/other/account_name | 60/384 | 15.62% | False |
| grant_mapping/snapshot/other/owner_name | 44/384 | 11.46% | False |
| grant_mapping/snapshot/other/possessive | 25/384 | 6.51% | False |
| grant_mapping/snapshot/self/account_name | 54/384 | 14.06% | False |
| grant_mapping/snapshot/self/owner_name | 43/384 | 11.20% | False |
| grant_mapping/snapshot/self/possessive | 32/384 | 8.33% | False |
| ownership/after_both/other/account_name | 118/768 | 15.36% | False |
| ownership/after_both/other/owner_name | 63/768 | 8.20% | False |
| ownership/after_both/other/possessive | 60/768 | 7.81% | False |
| ownership/after_both/self/account_name | 117/768 | 15.23% | False |
| ownership/after_both/self/owner_name | 75/768 | 9.77% | False |
| ownership/after_both/self/possessive | 38/768 | 4.95% | False |
| ownership/before/other/account_name | 23/192 | 11.98% | True |
| ownership/before/other/owner_name | 19/192 | 9.90% | True |
| ownership/before/other/possessive | 19/192 | 9.90% | False |
| ownership/before/self/account_name | 31/192 | 16.15% | True |
| ownership/before/self/owner_name | 23/192 | 11.98% | True |
| ownership/before/self/possessive | 17/192 | 8.85% | False |
| ownership/snapshot/other/account_name | 57/384 | 14.84% | True |
| ownership/snapshot/other/owner_name | 44/384 | 11.46% | True |
| ownership/snapshot/other/possessive | 24/384 | 6.25% | False |
| ownership/snapshot/self/account_name | 60/384 | 15.62% | True |
| ownership/snapshot/self/owner_name | 44/384 | 11.46% | True |
| ownership/snapshot/self/possessive | 31/384 | 8.07% | False |

Every one of eight named lookup cells and eight corresponding pair cells must reach 80%. Possessive errors are outcomes, not screening exclusions. Passing those controls does not establish dynamic update competence or authorize an intervention. After-both named controls and both event orders remain visible.

## Scope and reading guide

The report retains all stage/order contrasts, both owner-name comparisons, score margins, world-level effects, and accuracy by account, operator, answer position, command and order in analysis.json. Those are descriptive analyses, not replacement endpoints. examples.md uses the example selected before responses; it does not select an unusually strong model answer.

If E and F pass but S does not, the candidate concerns reference-sensitive own-query behavior without demonstrated own-versus-other specificity. A negative or incomplete result cannot establish unchanged behavior. This task does not measure private internal access, subjective experience or human illusionism.
