# Query-bound self-reference: fixed-sample report

Recorded Qwen2.5-7B-Instruct selections; one permission template.

Status: **incomplete_or_invalid**. Recorded 2688/16128 choices; 8/48 valid complete worlds.
Decision: **incomplete_or_invalid_no_inference**.

All 16128 scheduled cases remain in denominators, including missing as invalid administrative failures. No inferential CI/test with incomplete or invalid worlds. Undefined tests cannot qualify. E and F are correlated. Passing lookup does not establish dynamic competence or authorize interventions. No equivalence, consciousness or human-illusionism conclusion.

## The question

An operator owns one of two accounts. We ask for a successful command using either your/their active connection, the operator's name, or the same account's name. Within each comparison the task facts and correct answer are identical. In the primary checkpoint both accounts have changed permissions; reversing update order keeps the answer fixed. A rule that always chooses the newest grant succeeds on half the primary cases.

## Prespecified contrasts

For each world, $E=q_{self,possessive}-q_{self,account}$, $F=A_{self,account}-A_{self,possessive}$ and $S=F-(A_{other,account}-A_{other,possessive})$.

Positive E means more foreign-account choices; positive F means an accuracy cost. Positive S means a larger cost for the addressee than for the other operator. All three expected directions were fixed before responses. E and F are correlated, not independent replications. F−E is the contrast in remaining errors.

10000 paired world draws, seed 1729; nominal 95% CIs. Two-sided paired-world t tests, df 47, normal-mean approximation; Holm over E,F,S only.

| Contrast | Estimate (pp) | Nominal 95% CI (pp) | Raw p | Holm p | Test status |
|---|---:|---|---:|---:|---|
| E | +6.576 | withheld | None | 1 | incomplete_or_invalid_worlds |
| F | +6.641 | withheld | None | 1 | incomplete_or_invalid_worlds |
| S | +2.539 | withheld | None | 1 | incomplete_or_invalid_worlds |

Undefined tests use a labeled conservative value of 1 only inside Holm; they cannot qualify. Zero variance never proves equivalence.

## Accuracy, foreign choices and error budgets

| Stage / owner / alias | Correct / scheduled | Accuracy (%) | Foreign (%) | Error budget (%) | Margin (nats) | Missing / invalid recorded |
|---|---:|---:|---:|---:|---:|---:|
| after_both/other/account_name | 249/1536 | 16.21 | 0.33 | 83.79 | +8.955 | 1280 / 0 |
| after_both/other/owner_name | 191/1536 | 12.43 | 3.97 | 87.57 | +3.227 | 1280 / 0 |
| after_both/other/possessive | 186/1536 | 12.11 | 4.56 | 87.89 | +1.847 | 1280 / 0 |
| after_both/self/account_name | 246/1536 | 16.02 | 0.59 | 83.98 | +7.223 | 1280 / 0 |
| after_both/self/owner_name | 184/1536 | 11.98 | 3.97 | 88.02 | +3.235 | 1280 / 0 |
| after_both/self/possessive | 144/1536 | 9.38 | 7.16 | 90.62 | +0.860 | 1280 / 0 |
| before/other/account_name | 61/384 | 15.89 | 0.78 | 84.11 | +12.321 | 320 / 0 |
| before/other/owner_name | 53/384 | 13.80 | 2.86 | 86.20 | +7.233 | 320 / 0 |
| before/other/possessive | 50/384 | 13.02 | 3.65 | 86.98 | +4.022 | 320 / 0 |
| before/self/account_name | 52/384 | 13.54 | 0.52 | 86.46 | +10.579 | 320 / 0 |
| before/self/owner_name | 50/384 | 13.02 | 0.78 | 86.98 | +6.741 | 320 / 0 |
| before/self/possessive | 47/384 | 12.24 | 4.43 | 87.76 | +4.676 | 320 / 0 |
| snapshot/other/account_name | 124/768 | 16.15 | 0.52 | 83.85 | +14.170 | 640 / 0 |
| snapshot/other/owner_name | 101/768 | 13.15 | 3.52 | 86.85 | +7.928 | 640 / 0 |
| snapshot/other/possessive | 86/768 | 11.20 | 5.47 | 88.80 | +3.710 | 640 / 0 |
| snapshot/self/account_name | 120/768 | 15.62 | 0.52 | 84.38 | +11.811 | 640 / 0 |
| snapshot/self/owner_name | 97/768 | 12.63 | 2.08 | 87.37 | +6.828 | 640 / 0 |
| snapshot/self/possessive | 88/768 | 11.46 | 5.21 | 88.54 | +4.420 | 640 / 0 |

At the **fixed observed accuracies**, the categorical contrast E is bounded by [-83.984, +90.625] pp. This is not a pre-run generator bound. All-success cells and all error budgets are retained in analysis.json. The accuracy endpoint remains ceiling-limited too.

Revoked-target/other categories are not applicable before updates or in snapshots without printed history. Missing observations are administrative invalids, included in all-scheduled denominators and identified separately. Error-conditional shares use scheduled failures including missing cases; with no errors they are undefined. Incomplete-data estimates are descriptive and have no inferential CI or test.

## Lookup and paired controls

Lookup numerical thresholds passed: **False**. Eligible model gate passed: **False**.

| Control | Fully correct pairs / scheduled | Rate | Required gate |
|---|---:|---:|---|
| event_order/after_both/other/account_name | 122/768 | 15.89% | False |
| event_order/after_both/other/owner_name | 68/768 | 8.85% | False |
| event_order/after_both/other/possessive | 70/768 | 9.11% | False |
| event_order/after_both/self/account_name | 118/768 | 15.36% | False |
| event_order/after_both/self/owner_name | 75/768 | 9.77% | False |
| event_order/after_both/self/possessive | 46/768 | 5.99% | False |
| grant_mapping/after_both/other/account_name | 121/768 | 15.76% | False |
| grant_mapping/after_both/other/owner_name | 81/768 | 10.55% | False |
| grant_mapping/after_both/other/possessive | 69/768 | 8.98% | False |
| grant_mapping/after_both/self/account_name | 118/768 | 15.36% | False |
| grant_mapping/after_both/self/owner_name | 67/768 | 8.72% | False |
| grant_mapping/after_both/self/possessive | 49/768 | 6.38% | False |
| grant_mapping/snapshot/other/account_name | 60/384 | 15.62% | False |
| grant_mapping/snapshot/other/owner_name | 37/384 | 9.64% | False |
| grant_mapping/snapshot/other/possessive | 23/384 | 5.99% | False |
| grant_mapping/snapshot/self/account_name | 56/384 | 14.58% | False |
| grant_mapping/snapshot/self/owner_name | 38/384 | 9.90% | False |
| grant_mapping/snapshot/self/possessive | 31/384 | 8.07% | False |
| ownership/after_both/other/account_name | 123/768 | 16.02% | False |
| ownership/after_both/other/owner_name | 66/768 | 8.59% | False |
| ownership/after_both/other/possessive | 60/768 | 7.81% | False |
| ownership/after_both/self/account_name | 118/768 | 15.36% | False |
| ownership/after_both/self/owner_name | 59/768 | 7.68% | False |
| ownership/after_both/self/possessive | 29/768 | 3.78% | False |
| ownership/before/other/account_name | 22/192 | 11.46% | True |
| ownership/before/other/owner_name | 21/192 | 10.94% | True |
| ownership/before/other/possessive | 18/192 | 9.38% | False |
| ownership/before/self/account_name | 30/192 | 15.62% | True |
| ownership/before/self/owner_name | 19/192 | 9.90% | True |
| ownership/before/self/possessive | 15/192 | 7.81% | False |
| ownership/snapshot/other/account_name | 59/384 | 15.36% | True |
| ownership/snapshot/other/owner_name | 37/384 | 9.64% | True |
| ownership/snapshot/other/possessive | 22/384 | 5.73% | False |
| ownership/snapshot/self/account_name | 60/384 | 15.62% | True |
| ownership/snapshot/self/owner_name | 35/384 | 9.11% | True |
| ownership/snapshot/self/possessive | 25/384 | 6.51% | False |

Every one of eight named lookup cells and eight corresponding pair cells must reach 80%. Possessive errors are outcomes, not screening exclusions. Passing those controls does not establish dynamic update competence or authorize an intervention. After-both named controls and both event orders remain visible.

## Scope and reading guide

The report retains all stage/order contrasts, both owner-name comparisons, score margins, world-level effects, and accuracy by account, operator, answer position, command and order in analysis.json. Those are descriptive analyses, not replacement endpoints. examples.md uses the example selected before responses; it does not select an unusually strong model answer.

If E and F pass but S does not, the candidate concerns reference-sensitive own-query behavior without demonstrated own-versus-other specificity. A negative or incomplete result cannot establish unchanged behavior. This task does not measure private internal access, subjective experience or human illusionism.
