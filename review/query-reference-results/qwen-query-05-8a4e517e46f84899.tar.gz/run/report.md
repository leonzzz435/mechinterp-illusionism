# Query-bound self-reference: fixed-sample report

Recorded Qwen2.5-7B-Instruct selections; one permission template.

Status: **incomplete_or_invalid**. Recorded 2688/16128 choices; 8/48 valid complete worlds.
Decision: **incomplete_or_invalid_no_inference**.

All 16128 scheduled cases remain in denominators, including missing as invalid administrative failures. No inferential CI/test with incomplete or invalid worlds. Undefined tests cannot qualify. E and F are correlated. Passing lookup does not establish dynamic competence or authorize interventions. No equivalence, consciousness or human-illusionism conclusion.

## The question

An operator owns one of two accounts. We ask for a successful command using either your/their active connection, the operator's name, or the same account's name. Within each comparison the task facts and correct answer are identical. In the primary checkpoint both accounts have changed permissions; reversing update order keeps the answer fixed. A rule that always chooses the newest grant succeeds on half the primary cases.

## Prespecified contrasts

For each world, $E=q_{self,possessive}-q_{self,account}$, $F=A_{self,account}-A_{self,possessive}$ and $S=F-(A_{other,account}-A_{other,possessive})$.

Positive E means more foreign-account choices; positive F means an accuracy cost. Positive S means a larger cost for the addressee than for the other operator. All three expected directions were fixed before responses. E and F are correlated, not independent replications. F−E is the contrast in remaining errors.

10000 paired world draws, seed 1729; nominal 95% CIs. Two-sided paired-world t tests, df 47, normal-mean approximation; Holm over E,F,S only.

| Contrast | Estimate (pp) | Nominal 95% CI (pp) | Raw p | Holm p | Test status |
|---|---:|---|---:|---:|---|
| E | +5.599 | withheld | None | 1 | incomplete_or_invalid_worlds |
| F | +5.534 | withheld | None | 1 | incomplete_or_invalid_worlds |
| S | +0.977 | withheld | None | 1 | incomplete_or_invalid_worlds |

Undefined tests use a labeled conservative value of 1 only inside Holm; they cannot qualify. Zero variance never proves equivalence.

## Accuracy, foreign choices and error budgets

| Stage / owner / alias | Correct / scheduled | Accuracy (%) | Foreign (%) | Error budget (%) | Margin (nats) | Missing / invalid recorded |
|---|---:|---:|---:|---:|---:|---:|
| after_both/other/account_name | 252/1536 | 16.41 | 0.26 | 83.59 | +8.834 | 1280 / 0 |
| after_both/other/owner_name | 212/1536 | 13.80 | 2.80 | 86.20 | +3.581 | 1280 / 0 |
| after_both/other/possessive | 182/1536 | 11.85 | 4.82 | 88.15 | +1.483 | 1280 / 0 |
| after_both/self/account_name | 243/1536 | 15.82 | 0.52 | 84.18 | +7.632 | 1280 / 0 |
| after_both/self/owner_name | 184/1536 | 11.98 | 3.12 | 88.02 | +3.567 | 1280 / 0 |
| after_both/self/possessive | 158/1536 | 10.29 | 6.12 | 89.71 | +1.567 | 1280 / 0 |
| before/other/account_name | 63/384 | 16.41 | 0.26 | 83.59 | +13.068 | 320 / 0 |
| before/other/owner_name | 57/384 | 14.84 | 1.82 | 85.16 | +9.019 | 320 / 0 |
| before/other/possessive | 44/384 | 11.46 | 5.21 | 88.54 | +4.575 | 320 / 0 |
| before/self/account_name | 53/384 | 13.80 | 1.30 | 86.20 | +10.141 | 320 / 0 |
| before/self/owner_name | 51/384 | 13.28 | 1.82 | 86.72 | +7.809 | 320 / 0 |
| before/self/possessive | 45/384 | 11.72 | 4.95 | 88.28 | +5.090 | 320 / 0 |
| snapshot/other/account_name | 126/768 | 16.41 | 0.26 | 83.59 | +15.429 | 640 / 0 |
| snapshot/other/owner_name | 112/768 | 14.58 | 1.95 | 85.42 | +10.684 | 640 / 0 |
| snapshot/other/possessive | 95/768 | 12.37 | 4.30 | 87.63 | +4.965 | 640 / 0 |
| snapshot/self/account_name | 119/768 | 15.49 | 0.52 | 84.51 | +12.423 | 640 / 0 |
| snapshot/self/owner_name | 97/768 | 12.63 | 1.43 | 87.37 | +8.109 | 640 / 0 |
| snapshot/self/possessive | 100/768 | 13.02 | 3.65 | 86.98 | +5.976 | 640 / 0 |

At the **fixed observed accuracies**, the categorical contrast E is bounded by [-84.180, +89.714] pp. This is not a pre-run generator bound. All-success cells and all error budgets are retained in analysis.json. The accuracy endpoint remains ceiling-limited too.

Revoked-target/other categories are not applicable before updates or in snapshots without printed history. Missing observations are administrative invalids, included in all-scheduled denominators and identified separately. Error-conditional shares use scheduled failures including missing cases; with no errors they are undefined. Incomplete-data estimates are descriptive and have no inferential CI or test.

## Lookup and paired controls

Lookup numerical thresholds passed: **False**. Eligible model gate passed: **False**.

| Control | Fully correct pairs / scheduled | Rate | Required gate |
|---|---:|---:|---|
| event_order/after_both/other/account_name | 124/768 | 16.15% | False |
| event_order/after_both/other/owner_name | 91/768 | 11.85% | False |
| event_order/after_both/other/possessive | 64/768 | 8.33% | False |
| event_order/after_both/self/account_name | 116/768 | 15.10% | False |
| event_order/after_both/self/owner_name | 74/768 | 9.64% | False |
| event_order/after_both/self/possessive | 55/768 | 7.16% | False |
| grant_mapping/after_both/other/account_name | 124/768 | 16.15% | False |
| grant_mapping/after_both/other/owner_name | 91/768 | 11.85% | False |
| grant_mapping/after_both/other/possessive | 69/768 | 8.98% | False |
| grant_mapping/after_both/self/account_name | 116/768 | 15.10% | False |
| grant_mapping/after_both/self/owner_name | 69/768 | 8.98% | False |
| grant_mapping/after_both/self/possessive | 54/768 | 7.03% | False |
| grant_mapping/snapshot/other/account_name | 62/384 | 16.15% | False |
| grant_mapping/snapshot/other/owner_name | 48/384 | 12.50% | False |
| grant_mapping/snapshot/other/possessive | 33/384 | 8.59% | False |
| grant_mapping/snapshot/self/account_name | 55/384 | 14.32% | False |
| grant_mapping/snapshot/self/owner_name | 40/384 | 10.42% | False |
| grant_mapping/snapshot/self/possessive | 40/384 | 10.42% | False |
| ownership/after_both/other/account_name | 121/768 | 15.76% | False |
| ownership/after_both/other/owner_name | 86/768 | 11.20% | False |
| ownership/after_both/other/possessive | 55/768 | 7.16% | False |
| ownership/after_both/self/account_name | 119/768 | 15.49% | False |
| ownership/after_both/self/owner_name | 60/768 | 7.81% | False |
| ownership/after_both/self/possessive | 34/768 | 4.43% | False |
| ownership/before/other/account_name | 25/192 | 13.02% | True |
| ownership/before/other/owner_name | 25/192 | 13.02% | True |
| ownership/before/other/possessive | 12/192 | 6.25% | False |
| ownership/before/self/account_name | 28/192 | 14.58% | True |
| ownership/before/self/owner_name | 20/192 | 10.42% | True |
| ownership/before/self/possessive | 15/192 | 7.81% | False |
| ownership/snapshot/other/account_name | 59/384 | 15.36% | True |
| ownership/snapshot/other/owner_name | 48/384 | 12.50% | True |
| ownership/snapshot/other/possessive | 31/384 | 8.07% | False |
| ownership/snapshot/self/account_name | 60/384 | 15.62% | True |
| ownership/snapshot/self/owner_name | 42/384 | 10.94% | True |
| ownership/snapshot/self/possessive | 39/384 | 10.16% | False |

Every one of eight named lookup cells and eight corresponding pair cells must reach 80%. Possessive errors are outcomes, not screening exclusions. Passing those controls does not establish dynamic update competence or authorize an intervention. After-both named controls and both event orders remain visible.

## Scope and reading guide

The report retains all stage/order contrasts, both owner-name comparisons, score margins, world-level effects, and accuracy by account, operator, answer position, command and order in analysis.json. Those are descriptive analyses, not replacement endpoints. examples.md uses the example selected before responses; it does not select an unusually strong model answer.

If E and F pass but S does not, the candidate concerns reference-sensitive own-query behavior without demonstrated own-versus-other specificity. A negative or incomplete result cannot establish unchanged behavior. This task does not measure private internal access, subjective experience or human illusionism.
